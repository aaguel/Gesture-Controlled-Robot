/*******************************************************************************
* File Name: hall_effectpin.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_hall_effectpin_H) /* Pins hall_effectpin_H */
#define CY_PINS_hall_effectpin_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "hall_effectpin_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 hall_effectpin__PORT == 15 && ((hall_effectpin__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    hall_effectpin_Write(uint8 value);
void    hall_effectpin_SetDriveMode(uint8 mode);
uint8   hall_effectpin_ReadDataReg(void);
uint8   hall_effectpin_Read(void);
void    hall_effectpin_SetInterruptMode(uint16 position, uint16 mode);
uint8   hall_effectpin_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the hall_effectpin_SetDriveMode() function.
     *  @{
     */
        #define hall_effectpin_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define hall_effectpin_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define hall_effectpin_DM_RES_UP          PIN_DM_RES_UP
        #define hall_effectpin_DM_RES_DWN         PIN_DM_RES_DWN
        #define hall_effectpin_DM_OD_LO           PIN_DM_OD_LO
        #define hall_effectpin_DM_OD_HI           PIN_DM_OD_HI
        #define hall_effectpin_DM_STRONG          PIN_DM_STRONG
        #define hall_effectpin_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define hall_effectpin_MASK               hall_effectpin__MASK
#define hall_effectpin_SHIFT              hall_effectpin__SHIFT
#define hall_effectpin_WIDTH              1u

/* Interrupt constants */
#if defined(hall_effectpin__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in hall_effectpin_SetInterruptMode() function.
     *  @{
     */
        #define hall_effectpin_INTR_NONE      (uint16)(0x0000u)
        #define hall_effectpin_INTR_RISING    (uint16)(0x0001u)
        #define hall_effectpin_INTR_FALLING   (uint16)(0x0002u)
        #define hall_effectpin_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define hall_effectpin_INTR_MASK      (0x01u) 
#endif /* (hall_effectpin__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define hall_effectpin_PS                     (* (reg8 *) hall_effectpin__PS)
/* Data Register */
#define hall_effectpin_DR                     (* (reg8 *) hall_effectpin__DR)
/* Port Number */
#define hall_effectpin_PRT_NUM                (* (reg8 *) hall_effectpin__PRT) 
/* Connect to Analog Globals */                                                  
#define hall_effectpin_AG                     (* (reg8 *) hall_effectpin__AG)                       
/* Analog MUX bux enable */
#define hall_effectpin_AMUX                   (* (reg8 *) hall_effectpin__AMUX) 
/* Bidirectional Enable */                                                        
#define hall_effectpin_BIE                    (* (reg8 *) hall_effectpin__BIE)
/* Bit-mask for Aliased Register Access */
#define hall_effectpin_BIT_MASK               (* (reg8 *) hall_effectpin__BIT_MASK)
/* Bypass Enable */
#define hall_effectpin_BYP                    (* (reg8 *) hall_effectpin__BYP)
/* Port wide control signals */                                                   
#define hall_effectpin_CTL                    (* (reg8 *) hall_effectpin__CTL)
/* Drive Modes */
#define hall_effectpin_DM0                    (* (reg8 *) hall_effectpin__DM0) 
#define hall_effectpin_DM1                    (* (reg8 *) hall_effectpin__DM1)
#define hall_effectpin_DM2                    (* (reg8 *) hall_effectpin__DM2) 
/* Input Buffer Disable Override */
#define hall_effectpin_INP_DIS                (* (reg8 *) hall_effectpin__INP_DIS)
/* LCD Common or Segment Drive */
#define hall_effectpin_LCD_COM_SEG            (* (reg8 *) hall_effectpin__LCD_COM_SEG)
/* Enable Segment LCD */
#define hall_effectpin_LCD_EN                 (* (reg8 *) hall_effectpin__LCD_EN)
/* Slew Rate Control */
#define hall_effectpin_SLW                    (* (reg8 *) hall_effectpin__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define hall_effectpin_PRTDSI__CAPS_SEL       (* (reg8 *) hall_effectpin__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define hall_effectpin_PRTDSI__DBL_SYNC_IN    (* (reg8 *) hall_effectpin__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define hall_effectpin_PRTDSI__OE_SEL0        (* (reg8 *) hall_effectpin__PRTDSI__OE_SEL0) 
#define hall_effectpin_PRTDSI__OE_SEL1        (* (reg8 *) hall_effectpin__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define hall_effectpin_PRTDSI__OUT_SEL0       (* (reg8 *) hall_effectpin__PRTDSI__OUT_SEL0) 
#define hall_effectpin_PRTDSI__OUT_SEL1       (* (reg8 *) hall_effectpin__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define hall_effectpin_PRTDSI__SYNC_OUT       (* (reg8 *) hall_effectpin__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(hall_effectpin__SIO_CFG)
    #define hall_effectpin_SIO_HYST_EN        (* (reg8 *) hall_effectpin__SIO_HYST_EN)
    #define hall_effectpin_SIO_REG_HIFREQ     (* (reg8 *) hall_effectpin__SIO_REG_HIFREQ)
    #define hall_effectpin_SIO_CFG            (* (reg8 *) hall_effectpin__SIO_CFG)
    #define hall_effectpin_SIO_DIFF           (* (reg8 *) hall_effectpin__SIO_DIFF)
#endif /* (hall_effectpin__SIO_CFG) */

/* Interrupt Registers */
#if defined(hall_effectpin__INTSTAT)
    #define hall_effectpin_INTSTAT            (* (reg8 *) hall_effectpin__INTSTAT)
    #define hall_effectpin_SNAP               (* (reg8 *) hall_effectpin__SNAP)
    
	#define hall_effectpin_0_INTTYPE_REG 		(* (reg8 *) hall_effectpin__0__INTTYPE)
#endif /* (hall_effectpin__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_hall_effectpin_H */


/* [] END OF FILE */
