# Component constraints for C:\Users\aa4154\Documents\PSoC Creator\Workspace01\Design01.cydsn\TopDesign\TopDesign.cysch
# Project: C:\Users\aa4154\Documents\PSoC Creator\Workspace01\Design01.cydsn\Design01.cyprj
# Date: Fri, 12 Dec 2025 17:46:10 GMT
